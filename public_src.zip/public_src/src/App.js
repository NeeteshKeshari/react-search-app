import React from 'react';
import 'tachyons';
import './App.css';
import Home from './Home';
import Login from './Login';
import Search from './Search';
import Menu from './Menu';

import { BrowserRouter, Route } from 'react-router-dom';

const App = () => {
  return (
    <BrowserRouter>
      <h1 className="fl w-100 dim tc">Star War Search</h1>
      <Menu />
      <switch>
       <Route path="/" exact component={Home} />
       <Route path="/Login" component={Login} />
       <Route path="/Search" component={Search} />
      </switch>
    </BrowserRouter>
  );
}

export default App;
