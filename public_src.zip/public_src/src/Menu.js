import React from 'react';
import './Menu.css';
import { Link } from 'react-router-dom';

const Menu = () => {
  return(
  <div className="fl w-100">
   <nav className="fl navstyle">
    <ul>
       <li className="fl w-third dim tc"> <Link to="">  Home </Link> </li>
       <li className="fl w-third dim tc"> <Link to="Login">  Login </Link> </li>
       <li className="fl w-third dim tc"> <Link to="Search"> Search </Link> </li>
    </ul>
   </nav>
  </div>
 )
}

export default Menu;