import React, { Component } from 'react';
class Login extends Component {

    constructor() {
        super();
        this.state = {
            userName: [],
            username: '',
            password: ''
        }
        
        this.updateInput = this.updateInput.bind(this);
        this.updateInputPassword = this.updateInputPassword.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    //Get the values from the JSON data
    componentDidMount() {
        fetch('https://swapi.co/api/people/1/?format=json')
        .then(response => response.json())
        .then(data => {
            console.log(data);
            this.setState({ myname: data.name })
            this.setState({ myPassword: data.birth_year})
        })
    }
    

    // Update the user input username
    updateInput(event){
        this.setState({ username: event.target.value})
    }

    // Update the user input password
    updateInputPassword(event){
        this.setState({ password: event.target.value})
    }
       
    // Handle Submit function
    handleSubmit(){
        console.log('Your input value is: ' + this.state.username)
        
        if (this.state.myname === this.state.username && this.state.myPassword === this.state.password){
            console.log('Login Valid');
            this.props.history.push('/Search')
        } else {
            alert("Input detail is not Valid.");
        }
    }

    render() {
        return (
        <div>
            <h1 className="fl w-100 tc">User Login</h1>
            <div className="w-100">
                <div className="db w-50 center-block">
                    <label for="username">Enter User Name</label>
                    <input type="text" className="pa1" onChange={this.updateInput}></input>
                </div>
                <div className="db w-50 center-block">
                    <label for="password">Enter Password</label>
                    <input type="password" className="pa1" onChange={this.updateInputPassword} />
                </div>
                <div className="db w-50 center-block">
                    <input type="submit" className="pa2" onClick={this.handleSubmit} ></input>
                </div>
            </div>
        </div>
        )
    }
}
export default Login;