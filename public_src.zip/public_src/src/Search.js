import React, {Component} from 'react';
class Search extends Component {

  constructor() {
      super();
      this.state = {
          userData: [],
      }
  }

  //Get the values from the JSON data
  componentDidMount() {
      fetch('https://swapi.co/api/planets/1/?format=json')
      .then(response => response.json())
      .then(data => {
          console.log(data);
          this.setState({ planetName: data.name })
          this.setState({ planetDiameter: data.diameter })
          this.setState({ planetDiameter: data.diameter })
          this.setState({ planetPopulation: data.population })
          this.setState({ planetClimate: data.climate })
      })
  }

  render() {
      return (
      <div>
          <h1 className="fl w-100 tc">Planet Information</h1>
          <div className="w-100">
              <div className="db w-70 center-block">
                <table class="collapse ba br2 b--black-10 pv2 ph3 mt4">
                  <tbody>
                    <tr class="striped--near-white ">
                      <td class="pv2 ph3">Plant Name:</td>
                      <td class="pv2 ph3">{this.state.planetName}</td>
                    </tr>
                    <tr class="striped--near-white ">
                      <td class="pv2 ph3">Plant diameter:</td>
                      <td class="pv2 ph3">{this.state.planetDiameter}</td>
                    </tr>
                    <tr class="striped--near-white ">
                      <td class="pv2 ph3">Plant Population:</td>
                      <td class="pv2 ph3">{this.state.planetPopulation}</td>
                    </tr>
                    <tr class="striped--near-white ">
                      <td class="pv2 ph3">Plant Climate:</td>
                      <td class="pv2 ph3">{this.state.planetClimate}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
          </div>
      </div>
      )
  }
}

export default Search;