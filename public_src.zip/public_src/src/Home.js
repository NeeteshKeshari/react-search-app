import React from 'react';
const Home = () => {
  return (
    <div className="fl w-100 tc align-middle">
      <h3>Welcome to STAR WAR Search App</h3>
      <h5 className="green pv3">Please login to know about Star Character.</h5>
    </div>
    
  )
}
export default Home;